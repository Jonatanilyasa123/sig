<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>SIG | Tips</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="images/unila.png" rel="icon">
  <link href="images/unila.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Squadfree
  * Template URL: https://bootstrapmade.com/squadfree-free-bootstrap-template-creative/
  * Updated: Mar 17 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>
  .tips-container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            padding: 30px;
            border-top: 6px solid #007acc;
        }
        .tips-container h1 {
            color: #005f99;
            text-align: center;
            font-size: 2em;
            margin-bottom: 20px;
        }
        .tips-container h2 {
            color: #007acc;
            border-bottom: 2px solid #007acc;
            padding-bottom: 5px;
            margin-top: 30px;
        }
        .tips-container ul {
            list-style: none;
            padding: 0;
        }
        .tips-container li {
            margin-bottom: 15px;
            padding-left: 25px;
            position: relative;
        }
        .tips-container li:before {
            content: '\2713';
            color: #007acc;
            font-size: 1.2em;
            position: absolute;
            left: 0;
            top: 0;
        }
        .tips-container .sublist {
            list-style-type: lower-alpha;
            padding-left: 25px;
        }
        .tips-container .no-sign {
            color: #d9534f;
        }
        .tips-container .no-sign:before {
            content: '\2717';
            color: #d9534f;
        }
        .highlight {
            background-color: #e6f7ff;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 15px;
        }

      </style>
   
</head>

<body>
<!-- ======= Header ======= -->
<header id="header" class="fixed-top header-transparent">
    <div class="container d-flex align-items-center justify-content-between position-relative">

      <div class="logo">
        <h1 class="text-light"><a href="index.html"><span><img src="images/unila.png" alt=""></span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="index.php">Home</a></li>
          <li><a class="nav-link scrollto active" href="tips.php">Tips</a></li>
          <li><a class="nav-link scrollto" href="kejadian.php">Kejadian</a></li>
          <li><a class="nav-link scrollto" href="maps.html">Full Maps</a></li>
        
          <li class="dropdown"><a href="#"><span>Gempabumi & Tsunami</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#"></a>Gempabumi Terkini (M > 5.0)</li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Gempabumi Dirasakan</a></li>
                  <li><a href="#">Gempabumi Realtime</a></li>
                  <li><a href="#">Skala Intensitas Gempabumi</a></li>
                  <li><a href="#">Skala MMI</a></li>
                </ul>
              </li>
              <li><a href="#">Gempabumi Dirasakan</a></li>
              <li><a href="#">Gempabumi Realtime</a></li>
              <li><a href="#">Skala MMI</a></li>
            </ul>
          </li>
          <li class="dropdown megamenu"><a href="#"><span>Gempabumi & Tsunami</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li>
                <strong>Column 1</strong>
                <a href="#">Column 1 link 1</a>
                <a href="#">Column 1 link 2</a>
                <a href="#">Column 1 link 3</a>
              </li>
              <li>
                <strong>Column 2</strong>
                <a href="#">Column 2 link 1</a>
                <a href="#">Column 2 link 2</a>
                <a href="#">Column 3 link 3</a>
              </li>
              <li>
                <strong>Column 3</strong>
                <a href="#">Column 3 link 1</a>
                <a href="#">Column 3 link 2</a>
                <a href="#">Column 3 link 3</a>
              </li>
              <li>
                <strong>Column 4</strong>
                <a href="#">Column 4 link 1</a>
                <a href="#">Column 4 link 2</a>
                <a href="#">Column 4 link 3</a>
              </li>
              <li>
                <strong>Column 5</strong>
                <a href="#">Column 5 link 1</a>
                <a href="#">Column 5 link 2</a>
                <a href="#">Column 5 link 3</a>
              </li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
  <section id="hero">
    <div class="hero-container" data-aos="fade-up">
        <h1>Peta Perseberan Gempa Bumi dan Tsunami Di Wilayah Lampung dan Sekitarnya</h1>
        <h2 id="dateTime" class="datetime"></h2>
        <a href="#about" class="btn-get-started scrollto"><i class="bx bx-chevrons-down"></i></a>
    </div>
    <iframe src="maps.html"></iframe>

</section><!-- End Hero -->
<br>
<br>
<br> <br>
<div class="tips-container">
        <h1>Kesiapsiagaan Sebelum Terjadinya Gempa Bumi dan Tsunami</h1>
        <h2>A. Saat Tidak Terjadi Gempa Bumi atau Tsunami, Apa yang Harus Dilakukan?</h2>
        <ul>
            <li>Mendokumentasikan dokumen & surat berharga dalam bentuk softcopy</li>
            <li>Mengetahui kebutuhan khusus anggota keluarga</li>
            <li>Berbagi peran dalam keluarga jika terjadi gempa atau tsunami dan memastikan seluruh anggota keluarga memahami cara mematikan listrik dan kompor</li>
            <li>Mencatat nomor darurat & menginformasikan kepada seluruh anggota keluarga</li>
            <li>Mengecek potensi listrik yang berbahaya jika terjadi gempa atau tsunami</li>
            <li>Mengetahui jalur evakuasi dan lokasi pengungsian</li>
            <li>Memahami peringatan dini gempa dan tsunami yang ada di wilayahnya</li>
            <li>Merencanakan dengan keluarga tempat pertemuan apabila keluarga terpencar ketika terjadi gempa atau tsunami</li>
            <li>Melakukan kerja bakti membersihkan lingkungan dengan rutin</li>
            <li>Menyiapkan "TAS SIAGA BENCANA" (bila perlu) dengan isi:
                <ul class="sublist">
                    <li>Pakaian untuk 3 hari & perlengkapan ibadah</li>
                    <li>Obat-obatan pribadi & perlengkapan P3K</li>
                    <li>Dokumen dan surat berharga (dibungkus plastik)</li>
                    <li>Sarung/Selimut</li>
                    <li>Foto Keluarga</li>
                    <li>Air Mineral</li>
                    <li>Powerbank & Baterai Cadangan</li>
                    <li>Peluit</li>
                    <li>Masker & Handsanitizer</li>
                    <li>Senter</li>
                    <li>Kantung plastik</li>
                    <li>Uang Tunai</li>
                    <li>Makanan ringan tahan lama</li>
                </ul>
            </li>
        </ul>
        <h2>B. Yang Tidak Boleh Dilakukan</h2>
        <ul>
            <li class="no-sign">Jangan mengabaikan risiko gempa dan tsunami di daerah Anda</li>
            <li class="no-sign">Jangan menyimpan dokumen dan surat berharga di area yang rawan rusak saat bencana</li>
            <li class="no-sign">Jangan memasang peralatan listrik di area yang tidak aman saat gempa atau tsunami</li>
            <li class="no-sign">Jangan mengabaikan peringatan dini dan jalur evakuasi yang telah ditetapkan</li>
        </ul>
    </div>
    </section><!-- End Services Section -->
    <br>
    <br>
  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3>Mata Kuliah</h3>
              <p class="pb-3"><em>SISTEM INFORMASI GEOGRAFIS</em></p>
            
       
            </div>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Nama Kelompok</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Jonatan Ilyasa</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Nur Ainun</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Meva Dinda Amara</a></li>
              
            </ul>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>NPM</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">2115061126</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">2115061126</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">2115061126</a></li>
              
            </ul>
          </div>


        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Jonatanilyasa.my.id</span></strong>
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/squadfree-free-bootstrap-template-creative/ -->
       
      </div>
    </div>
  </footer><!-- End Footer -->

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  
   
  
            
            


</body>

</html>