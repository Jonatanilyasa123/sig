<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cobalagi";

// Buat koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query SQL untuk mengambil data gempa bumi terbaru
$sql = "SELECT magnitude, date_time FROM gempa_bumi ORDER BY date_time DESC LIMIT 1";

// Eksekusi query
$result = $conn->query($sql);

// Periksa apakah query berhasil dieksekusi
if ($result) {
    // Periksa apakah ada data yang ditemukan
    if ($result->num_rows > 0) {
        // Ambil baris pertama hasil query
        $row = $result->fetch_assoc();
        
        // Buat array untuk diubah menjadi JSON
        $output = array(
            'magnitude' => $row['magnitude'],
            'date' => $row['date_time'] // Sesuaikan dengan nama kolom yang benar
        );

        // Mengembalikan data dalam format JSON
        echo json_encode($output);
    } else {
        echo json_encode(array()); // Jika tidak ada data yang ditemukan, mengembalikan array kosong
    }
} else {
    // Tampilkan pesan kesalahan jika query gagal dieksekusi
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Tutup koneksi ke database
$conn->close();
?>
