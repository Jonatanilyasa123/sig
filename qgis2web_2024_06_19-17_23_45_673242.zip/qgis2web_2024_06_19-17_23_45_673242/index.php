<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>SIG | Home</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="images/unila.png" rel="icon">
  <link href="images/unila.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Squadfree
  * Template URL: https://bootstrapmade.com/squadfree-free-bootstrap-template-creative/
  * Updated: Mar 17 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>
        /* Gaya CSS untuk tata letak dan animasi */
        #earthquakeNotification {
            position: fixed;
            bottom: 20px; /* Atur jarak dari bawah layar */
            left: 0;
            width: 100%;
            text-align: center;
            background-color: #f0f0f0;
            padding: 10px;
            display: none; /* Sembunyikan secara default */
        }
        
        /* Animasi untuk membuat div berjalan dari kanan ke kiri */
        @keyframes slide-left {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
        }
        
        /* Kelas untuk warna hijau */
        .green {
            color: green;
        }
        
        /* Kelas untuk warna merah */
        .red {
            color: red;
        }
    </style>
 
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-transparent">
    <div class="container d-flex align-items-center justify-content-between position-relative">

      <div class="logo">
        <h1 class="text-light"><a href="index.html"><span><img src="images/unila.png" alt=""></span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="tips.php">Tips</a></li>
          <li><a class="nav-link scrollto" href="kejadian.php">Kejadian</a></li>
          <li><a class="nav-link scrollto" href="maps.html">Full Maps</a></li>
        
          <li class="dropdown"><a href="#"><span>Gempabumi & Tsunami</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#"></a>Gempabumi Terkini (M > 5.0)</li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Gempabumi Dirasakan</a></li>
                  <li><a href="#">Gempabumi Realtime</a></li>
                  <li><a href="#">Skala Intensitas Gempabumi</a></li>
                  <li><a href="#">Skala MMI</a></li>
                </ul>
              </li>
              <li><a href="#">Gempabumi Dirasakan</a></li>
              <li><a href="#">Gempabumi Realtime</a></li>
              <li><a href="#">Skala MMI</a></li>
            </ul>
          </li>
          <li class="dropdown megamenu"><a href="#"><span>Gempabumi & Tsunami</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li>
                <strong>Column 1</strong>
                <a href="#">Column 1 link 1</a>
                <a href="#">Column 1 link 2</a>
                <a href="#">Column 1 link 3</a>
              </li>
              <li>
                <strong>Column 2</strong>
                <a href="#">Column 2 link 1</a>
                <a href="#">Column 2 link 2</a>
                <a href="#">Column 3 link 3</a>
              </li>
              <li>
                <strong>Column 3</strong>
                <a href="#">Column 3 link 1</a>
                <a href="#">Column 3 link 2</a>
                <a href="#">Column 3 link 3</a>
              </li>
              <li>
                <strong>Column 4</strong>
                <a href="#">Column 4 link 1</a>
                <a href="#">Column 4 link 2</a>
                <a href="#">Column 4 link 3</a>
              </li>
              <li>
                <strong>Column 5</strong>
                <a href="#">Column 5 link 1</a>
                <a href="#">Column 5 link 2</a>
                <a href="#">Column 5 link 3</a>
              </li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container" data-aos="fade-up">
        <h1>Peta Perseberan Gempa Bumi dan Tsunami Di Wilayah Lampung dan Sekitarnya</h1>
        <h2 id="dateTime" class="datetime"></h2>
        <a href="#about" class="btn-get-started scrollto"><i class="bx bx-chevrons-down"></i></a>
    </div>
    <iframe src="maps.html"></iframe>

</section><!-- End Hero -->

<div id="earthquakeNotification"></div>



  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row no-gutters">
          <div class="content col-xl-5 d-flex align-items-stretch" data-aos="fade-up">
            <div class="content">
              <h3>Informasi Terkini Gempa Bumi dan Tsunami</h3>
              <p>
              Klik Lanjutkan Untuk Membaca Informasi dan Kejadian Terkini dari Seluruh Wilayah Indonesia</p>
              <a href="#" class="about-btn">Lanjutkan <i class="bx bx-chevron-right"></i></a>
            </div>
          </div>
          <div class="col-xl-7 d-flex align-items-stretch">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100">
                  <img src="images/bmkg.jpg" alt="" style="width: 200px; height: 150px;">
                  <h4>Gempa Bumi Wilayah Lampung dan Wilayah II</h4>
                  <p><a href="https://lampung.bmkg.go.id/info/?ase=viwlasteg&r=geofisika">Disclaimer: wilayah II merupakan wilayah monitoring gempabumi meliputi provinsi Lampung, Bengkulu, sumatera selatan, banten, jawabarat dan Jakarta.</a></p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="200">
                <img src="images/bmkg2.jpg" alt="" style="width: 200px; height: 150px;">
                  <h4>Gempa M 4,6 Guncang Lampung</h4>
                  <p><a href="https://news.detik.com/berita/d-7386551/gempa-m-4-6-guncang-lampung">Gempa Berkekuatan 4,6 Magnitudo Terjadi di Lampung Pada Kedalaman 10 Km</a></p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="300">
                <img src="images/bmkg3.jpg" alt="" style="width: 200px; height: 150px;">
                  <h4>Gempa M 4,9 Guncang Pesisir Barat</h4>
                  <p><a href="https://news.detik.com/berita/d-6940025/gempa-m-4-9-terjadi-di-pesisir-barat-lampung">Gempa Berkekuatan 4,6 Magnitudo Terjadi di Pesisir barat Pada Kedalaman 10 Km</a></p>
                </div>
                <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="400">
                <img src="images/bmkg4.jpg" alt="" style="width: 200px; height: 150px;">
                  <h4>Nias dan Sejumlah Wilayah di Indonesia Di Guncang Gempa</h4>
                  <p><a href="https://www.detik.com/sumut/berita/d-6442766/nias-dan-sejumlah-wilayah-di-indonesia-diguncang-gempa">Sejumlah Wilayah di Indonesia di Guncang Gempa Pada Senin (15/12/2022)</a></p>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title" data-aos="fade-in" data-aos-delay="100">
          <h2>Peta Persebaran Sensor</h2>
          <p>Data berikut di Ambil dari Sensor PUMMA U-TEWS 003 yang berada pada titik berikut ini tepatnya berada di Kecamatan Panjang, Kota Bandar Lampung, Provinsi Lampung.</p>
        </div>

       <?php  include "coba/index.php"; ?>

        </div>

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Chart</h2>
          <p>Berikut Adalah Data Chart Gempa Bumi yang di Tangkap Oleh Sensor Beserta Waktu Kejadian. </p>
        </div>

        
    

        </div>

        <div class="row">

         

          
        <?php  include "chart/chart.php"; ?>
          
        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

      </div>
    </section><!-- End Services Section -->
 <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3>Mata Kuliah</h3>
              <p class="pb-3"><em>SISTEM INFORMASI GEOGRAFIS</em></p>
            
       
            </div>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Nama Kelompok</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Jonatan Ilyasa</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Nur Ainun</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Meva Dinda Amara</a></li>
              
            </ul>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>NPM</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">2115061126</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">2115061126</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">2115061126</a></li>
              
            </ul>
          </div>


        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Jonatanilyasa.my.id</span></strong>
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/squadfree-free-bootstrap-template-creative/ -->
       
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <script>
    function updateDateTime() {
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit', 
            hour12: false, 
            timeZoneName: 'short' 
        };
        const now = new Date();
        const dateTimeString = now.toLocaleDateString('id-ID', options);
        document.getElementById('dateTime').textContent = dateTimeString;
    }

    setInterval(updateDateTime, 1000);
    updateDateTime();
</script>
  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  
   
    <!-- Script JavaScript untuk memuat data secara dinamis -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            function loadData() {
                $.ajax({
                    url: 'load_data.php', // Sesuaikan dengan alamat file PHP yang mengambil data
                    type: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        if (data) {
                            updateEarthquakeNotification(data.magnitude, data.date, data.location, data.depth, data.tsunami_potential);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error: ' + status + ' ' + error);
                    }
                });
            }

            function updateEarthquakeNotification(magnitude, date, location, depth, tsunamiPotential) {
                const notification = $('#earthquakeNotification');
                let colorClass = '';

                // Tentukan warna berdasarkan magnitudo
                if (magnitude >= 2.5 && magnitude <= 4.5) {
                    colorClass = 'green';
                } else if (magnitude > 4.5 && magnitude <= 6.9) {
                    colorClass = 'red';
                }

                // Tentukan teks peringatan berdasarkan potensi tsunami
                let tsunamiWarning = '';
                if (tsunamiPotential === '1') {
                    tsunamiWarning = ', berpotensi tsunami';
                } else {
                    tsunamiWarning = ', tidak berpotensi tsunami';
                }

                // Buat konten notifikasi
                const content = `Gempa Mag: ${magnitude}, ${date} WIB, pusat gempa di ${location}, kedalaman ${depth} km${tsunamiWarning}`;

                // Set kelas warna dan isi notifikasi
                notification.text(content).removeClass('green red').addClass(colorClass).fadeIn();
                notification.css({
                    'animation': 'slide-left 10s linear infinite',
                    'animation-delay': '1s' // Delay animasi untuk memberi waktu untuk membaca
                });
            }

            // Pemanggilan loadData setiap 10 detik (misalnya)
            setInterval(loadData, 10000);
            loadData(); // Memuat data pertama kali saat halaman dimuat
        });
    </script>
</body>

</html>