<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>SIG | Kejadian</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="images/unila.png" rel="icon">
  <link href="images/unila.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Squadfree
  * Template URL: https://bootstrapmade.com/squadfree-free-bootstrap-template-creative/
  * Updated: Mar 17 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>
    body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f0f8ff;
    color: #333;
    margin: 0;
    padding: 0;
}

.kejadian-container {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.kejadian {
    margin-bottom: 20px;
}

.kejadian-title {
    color: #007acc;
    text-align: center;
}

.kejadian-timestamp {
    font-style: italic;
    color: #555;
    text-align: center;
}

.event-description, .impact, .damage {
    padding: 10px;
    background-color: #e6f7ff;
    border-left: 6px solid #007acc;
    border-radius: 4px;
}

.kejadian-subtitle {
    color: #007acc;
    margin-bottom: 10px;
    text-align: center;
}
  </style>
 
   
</head>

<body>
<!-- ======= Header ======= -->
<header id="header" class="fixed-top header-transparent">
    <div class="container d-flex align-items-center justify-content-between position-relative">

      <div class="logo">
        <h1 class="text-light"><a href="index.html"><span><img src="images/unila.png" alt=""></span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="index.php">Home</a></li>
          <li><a class="nav-link scrollto " href="tips.php">Tips</a></li>
          <li><a class="nav-link scrollto active" href="kejadian.php">Kejadian</a></li>
          <li><a class="nav-link scrollto" href="maps.html">Full Maps</a></li>
        
          <li class="dropdown"><a href="#"><span>Gempabumi & Tsunami</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#"></a>Gempabumi Terkini (M > 5.0)</li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Gempabumi Dirasakan</a></li>
                  <li><a href="#">Gempabumi Realtime</a></li>
                  <li><a href="#">Skala Intensitas Gempabumi</a></li>
                  <li><a href="#">Skala MMI</a></li>
                </ul>
              </li>
              <li><a href="#">Gempabumi Dirasakan</a></li>
              <li><a href="#">Gempabumi Realtime</a></li>
              <li><a href="#">Skala MMI</a></li>
            </ul>
          </li>
          <li class="dropdown megamenu"><a href="#"><span>Gempabumi & Tsunami</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li>
                <strong>Column 1</strong>
                <a href="#">Column 1 link 1</a>
                <a href="#">Column 1 link 2</a>
                <a href="#">Column 1 link 3</a>
              </li>
              <li>
                <strong>Column 2</strong>
                <a href="#">Column 2 link 1</a>
                <a href="#">Column 2 link 2</a>
                <a href="#">Column 3 link 3</a>
              </li>
              <li>
                <strong>Column 3</strong>
                <a href="#">Column 3 link 1</a>
                <a href="#">Column 3 link 2</a>
                <a href="#">Column 3 link 3</a>
              </li>
              <li>
                <strong>Column 4</strong>
                <a href="#">Column 4 link 1</a>
                <a href="#">Column 4 link 2</a>
                <a href="#">Column 4 link 3</a>
              </li>
              <li>
                <strong>Column 5</strong>
                <a href="#">Column 5 link 1</a>
                <a href="#">Column 5 link 2</a>
                <a href="#">Column 5 link 3</a>
              </li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <section id="hero">
    <div class="hero-container" data-aos="fade-up">
        <h1>Peta Perseberan Gempa Bumi dan Tsunami Di Wilayah Lampung dan Sekitarnya</h1>
        <h2 id="dateTime" class="datetime"></h2>
        <a href="#about" class="btn-get-started scrollto"><i class="bx bx-chevrons-down"></i></a>
    </div>
    <iframe src="maps.html"></iframe>
    </section><!-- End Hero -->

<br><br>
<br> <br>
    <div class="kejadian-container">
        <header class="kejadian">
            <h1 class="kejadian-title">Kejadian Tsunami Anak Krakatau</h1>
            <p class="kejadian-timestamp">Pada pukul 21:03 WIB (14:03 UTC/23:03 JST), Anak Krakatau meletus dan merusak peralatan seismografi terdekat, meskipun suatu stasiun lain mendeteksi getaran terus-menerus. Pada pukul 21:27 WIB, BMKG mendeteksi suatu tsunami di pesisir barat Banten, meskipun tidak ada peristiwa tektonik.[7] Menurut fakta yang ada, terjadi longsoran dari Gunung Krakatau sebanyak 64 hektare yang memicu goncangan yang berujung kepada tsunami.[8] Juru bicara Badan Nasional Penanggulangan Bencana (BNPB) Sutopo Purwo Nugroho merilis sebuah pernyataan yang menghubungkan tsunami dengan pasang tinggi dan longsor bawah laut yang disebabkan oleh letusan Anak Krakatau.[5] Menurut kesaksian Indira Rezkisari (wartawan Republika) yang menyaksikan detik-detik terjadinya tsunami, sebelum terjadinya tsunami itu memang sempat terdengar dentuman keras dari laut. Selain itu pula, Republika 24 Desember mencatat bahwa bencana menerpa tanpa adanya peringatan dini dari sensor tsunami.[9]

Sebelumnya, BMKG telah mengeluarkan peringatan gelombang tinggi untuk perairan sekitar selat Sunda.[10] Tercatat tinggi gelombang tsunami berkisar 90 sentimeter (35 in) di Serang dan 30 sentimeter (12 in) di Lampung,[11] dengan ketinggian maksimal 2 meter (6,6 ft).[12] Ihwal gelombang itu pun sempat tercatat dalam cuitan Twitter BMKG, sebelum pada akhirnya dihapus pada pukul 01.01 WIB.[13] Namun pada akhirnya, BMKG memverifikasi bahwa tsunami memang terjadi pada sekitar 21.30 WIB, beriringan dengan kondisi gelombang tinggi karena bulan purnama di Selat Sunda pada 21-25 Desember.[</p>
        </header>
        <section class="event-details kejadian">
            <div class="event-description kejadian">
                <p>Pada tanggal 22 Desember, laporan awal BNPB menunjukkan sedikitnya 20 orang tewas...</p>
            </div>
            <div class="impact kejadian">
                <h2 class="kejadian-subtitle">Korban</h2>
                <p>Pada tanggal 22 Desember, laporan awal BNPB menunjukkan sedikitnya 20 orang tewas dan 165 terluka, dan 2 orang dilaporkan hilang.[15] Pada tanggal 23 Desember, jumlah korban telah direvisi menjadi 43 tewas, 584 terluka, dan 2 hilang. Dari 43 korban jiwa, 33 tewas di Pandeglang, 7 di Lampung Selatan, dan 3 di Serang, dengan sebagian besar korban luka-luka (491 orang) juga di Pandeglang. Pada Minggu pukul 11:00 WIB, BNPB merevisi jumlah korban menjadi 62 tewas, 584 terluka, dan 20 hilang.[16] Pada Minggu pukul 13:00 WIB, BNPB merevisi jumlah korban yakni 168 meninggal dunia dan 745 luka-luka.[17] Wilayah yang terimbas tsunami di Pandeglang merupakan destinasi wisata seperti Pantai Carita.[18] Menurut Sutopo, lokasi di Pantai Carita yang banyak ditemukan korban ialah di Hotel Mutiara Carita Cottage, Hotel Tanjung Lesung, dan Kampung Sambolo. Memang daerah sana sedang dipadati wisatawan dan masyarakat setempat. Pantai seperti Pantai Tanjung Lesung, Pantai Teluk Lada, Pantai Panimbang, Pantai Sumur, dan Pantai Carita memang sedang ramai oleh turis yang berlibur.[9] Pukul 16.00 WIB, Sutopo Purwo Nugroho menyatakan melalui akun Twitternya bahwa korban terus bertambah. Ia menyatakan bahwa korban meninggal telah mencapai 222 orang, 843 orang luka, dan 28 orang masih hilang.[19][20][21] Pada tanggal 24 Desember 2018, Sutopo Purwo Nugroho menyatakan bahwasanya hingga pukul 07.00 berdasarkan data yang dihimpun oleh BNPB, jumlah korban tewas sebanyak 281 orang, 1.016 terluka, dan 57 orang lainnya masih hilang.[1] Pada 25 Desember, Humas BNPB menyatakan bahwa 429 orang meninggal, 1.485 orang luka-luka, 154 orang hilang, 16.082 orang mengungsi.[22] Korban dan kerusakan yang terdampak ialah dari Kabupaten Pandeglang, Kabupaten Serang, Kabupaten Lampung Selatan, dan Kabupaten Tanggamus.[21]

Beberapa korban di antaranya adalah Heriyanto alias Aa Jimmy, seorang komedian,[23] dan beberapa anggota grup musik Seventeen, di mana gitaris, basis, pemain drum dan manajer grup musik ditemukan meninggal dunia.[24] Sebuah video yang beredar menunjukkan panggung tempat grup musik Seventeen yang melaksanakan konser dalam rangka darmawisata rombongan karyawan PLN beserta keluarga di kawasan Tanjung Lesung tersapu oleh tsunami.[25] Pada pukul 16.10 WIB, Detik.com melansir dalam acara wisata itu, PLN menyebut ada 29 korban meninggal dari pihak PLN, 157 orang selamat, dan 13 lainnya masih hilang. Pihak PLN yang ikut acara kumpul pegawai beserta keluarganya berjumlah 199 orang.[26] Rombongan karyawan beserta keluarga dari Kementerian Pemuda dan Olahraga dan PLN yang sedang berwisata di sekitar pantai barat Banten turut menjadi korban, baik korban luka maupun korban jiwa, akibat tsunami.[27]

Sementara itu, rombongan santri SMA Islam Nurul Fikri Boarding School (NFBS) Serang yang menempati sebuah resor tepat di pinggir pantai di Umbul Tanjung selamat dari terjangan tsunami, walaupun bangunan di sekitar lokasi resor mereka luluh lantak akibat sapuan ombak.[28][29] Sebuah video yang beredar di media sosial memperlihatkan tempat rombongan santri SMA Islam NFBS "utuh tak tersentuh".[28] Seluruh rombongan sebanyak 55 santri selamat; mereka tengah melewati masa karantina menghafal Alquran dalam rangka persiapan pengambilan sanad ke Turki.[</p>
            </div>
            <div class="damage kejadian">
                <h2 class="kejadian-subtitle">Kerusakan</h2>
                <p>Sekitar 400 rumah di Pandeglang yang terletak di dekat pantai roboh atau rusak berat akibat tsunami. Selain itu, 9 hotel di Pandeglang dan 30 rumah di Lampung Selatan juga rusak berat.[31] Jalan raya yang menghubungkan Serang dan Pandeglang terputus.[32]

Kemudian, pada pukul 16.00, 23 Desember 2018, berita terbaru dari BNPB menyebutkan kerusakan material dari tsunami ini meliputi 556 unit rumah rusak, sembilan unit hotel rusak berat, 60 warung kuliner rusak, 350 kapal dan perahu rusak.[21] Di Pandeglang sendiri, didapati 73 unit kendaraan rusak, dan 446 rumah rusak. Pendataan kerusakan bangunan masih terus dilakukan.[21] Per 25 Desember, kerusakan material diketahui masih terus bertambah. 882 rumah yang rusak, 73 penginapan rusak dan 60 warung rusak. Pada kendaraan, tercatat bahwa 434 perahu dan kapal rusak, 24 kendaraan roda 4 rusak, 41 kendaraan roda 2 rusak. Selain itu pula, terdapat 1 dermaga rusak, dan 1 shelter rusak.[22] Kemudian menurut laporan daripada BBC Indonesia, hampir semua warung, toko, minimarket/swalayan kecil, termasuk di pantai-pantai wisata Anyer. Tumpukan puing ber serakan di tepi dan sudut jalan, yang sebagian besarnya oleh bangunan semi permanen. Ambulans dan mobil aparat berlalu lalang, dan di pelataran kantor polisi, telah berleret kantong dari jenazah yang telah ditemukan.[33] Selain itu, di bidang kelistrikan, ada 146 gardu listrik yang telah dapat dinyalakan. 102 masih padam, dan 20 saluran udara tegangan menengah roboh karena diterjang tsunami.[34]

Di Lampung Selatan, Desa Kunjir, Way Muli, dan Canti, menjadi desa yang paling terdampak bencana.[35][36] Republika mengutip salah satu kesaksian warga, bahwa di Way Muli, dalam waktu 4 menit, tsunami menghancurkan rumah-rumah yang ada. Gulungannya begitu tinggi, menggemuruh, dan terlihat ada kilat api. Desa yang semula memang padat penduduk dan rumah, menjadi rata dengan tanah.[36] Sampai pagi 24 Desember, menurut CNN Indonesia, sudah ada 60 orang ditemukan meninggal dunia, 22 orang hilang, dan 258 orang luka-luka.[35]</p>
            </div>
        </section>

 <!-- ======= Footer ======= -->
 <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3>Mata Kuliah</h3>
              <p class="pb-3"><em>SISTEM INFORMASI GEOGRAFIS</em></p>
            
       
            </div>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Nama Kelompok</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Jonatan Ilyasa</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Nur Ainun</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Meva Dinda Amara</a></li>
              
            </ul>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>NPM</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">2115061126</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">2115061126</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">2115061126</a></li>
              
            </ul>
          </div>


        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Jonatanilyasa.my.id</span></strong>
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/squadfree-free-bootstrap-template-creative/ -->
       
      </div>
    </div>
  </footer><!-- End Footer -->


  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  

</body>

</html>