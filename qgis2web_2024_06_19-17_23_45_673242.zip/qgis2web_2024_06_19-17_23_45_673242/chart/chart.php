<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chart Magnitude Gempa Bumi</title>
    <!-- Load Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Gaya CSS untuk container chart */
        #chartContainer {
            width: 80%;
            margin: auto;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Container untuk chart -->
    <div id="chartContainer">
        <canvas id="magnitudeChart"></canvas>
    </div>

    <?php
    // Koneksi ke database MySQL
    $servername = "localhost";
    $username = "root"; // Ganti dengan username database Anda
    $password = ""; // Ganti dengan password database Anda
    $dbname = "cobalagi"; // Ganti dengan nama database Anda

    // Buat koneksi
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi ke database gagal: " . $conn->connect_error);
    }

    // Query untuk mengambil data magnitude dan date_time
    $sql = "SELECT magnitude, date_time FROM gempa_bumi ORDER BY date_time ASC"; // Sesuaikan dengan nama tabel dan kolom Anda

    $result = $conn->query($sql);

    $data = array();

    // Ambil data dari hasil query
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = array(
                'magnitude' => $row['magnitude'],
                'date_time' => $row['date_time']
            );
        }
    } else {
        echo '<script>console.log("Data tidak ditemukan.");</script>';
    }

    // Konversi data ke format JSON untuk JavaScript
    $jsonData = json_encode($data);

    // Tutup koneksi
    $conn->close();
    ?>

    <!-- Script JavaScript untuk membuat chart -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const data = <?php echo $jsonData; ?>;

            // Fungsi untuk membuat chart menggunakan Chart.js
            function createChart(data) {
                // Data yang akan ditampilkan di chart (magnitudo dari setiap gempa)
                const magnitudes = data.map(entry => parseFloat(entry.magnitude));
                const dates = data.map(entry => entry.date_time);

                // Referensi elemen canvas untuk chart
                const ctx = document.getElementById('magnitudeChart').getContext('2d');

                // Buat chart menggunakan Chart.js
                const chart = new Chart(ctx, {
                    type: 'line', // Jenis chart (misalnya line untuk diagram garis)
                    data: {
                        labels: dates, // Label sumbu X (tanggal dan waktu)
                        datasets: [{
                            label: 'Magnitude Gempa', // Label dataset
                            data: magnitudes, // Data magnitudo
                            borderColor: 'rgba(54, 162, 235, 1)', // Warna garis batas garis
                            borderWidth: 1 // Lebar garis
                        }]
                    },
                    options: {
                        scales: {
                            y: { // Update options untuk Chart.js versi terbaru
                                beginAtZero: true // Mulai sumbu Y dari nilai 0
                            }
                        }
                    }
                });
            }

            // Panggil fungsi createChart dengan data dari PHP
            createChart(data);
        });
    </script>
</body>
</html>
