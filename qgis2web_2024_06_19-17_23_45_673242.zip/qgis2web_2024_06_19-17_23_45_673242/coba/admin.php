<?php
include "sensor/chart/koneksi.php";

if(isset($_POST['submit'])){
    $latitude = $_POST['latitude'];
    $latitude = $_POST['longitude'];
    $latitude = $_POST['name'];
    $latitude = $_POST['temperature'];
    $latitude = $_POST['humidity'];

}



?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action="admin.php" method="post">
        <input type="text" name="latitude">
        <input type="text" name="longitude">
        <input type="text" name="name">
        <input type="text" name="temperature">
        <input type="text" name="humidity">
        <input type="submit">
    </form>
</body>
</html>