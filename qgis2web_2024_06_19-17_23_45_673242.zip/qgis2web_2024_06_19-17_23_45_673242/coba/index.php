<!DOCTYPE html>
<html>
<head>
    <title>SIG</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style>
     .container {
        margin-top: 5px; /* Atur margin atas sesuai kebutuhan */
    }
</style>
</head>
<body>


<div id="map" style="height: 500px; margin-bottom: 1px;"></div>
<div class="container">
<?php include "sensor/sensor1/sensor1.php"; ?>


<?php include "sensor/sensor2/sensor2.php"; ?>
</div>






<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

<script>

    <?php include "baru2.php"; ?>
    var map = L.map('map').setView([-5.7124307,105.5705439], 13); 

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
    }).addTo(map);

    
    map.setMaxBounds(map.getBounds());

   
    var sensorData1 = <?php echo json_encode($sensorData1); ?>;
    var sensorData2 = <?php echo json_encode($sensorData2); ?>;
    var sensorData3 = <?php echo json_encode($sensorData3); ?>;
    var sensorData4 = <?php echo json_encode($sensorData4); ?>;
    var sensorData5 = <?php echo json_encode($sensorData5); ?>;
    var sensorData6 = <?php echo json_encode($sensorData6); ?>;

   
    var coordinates1 = [-5.714197, 105.573325];
    var coordinates2 = [-5.714175, 105.573990];
    var coordinates3 = [-5.714645, 105.572703];
    var coordinates4 = [-5.715499, 105.573475];
    var coordinates5 = [-5.713898, 105.571909];
    var coordinates6 = [-5.713331, 105.570965];

  
    addMarkers(sensorData1, coordinates1);
    addMarkers(sensorData2, coordinates2);
    addMarkers(sensorData3, coordinates3);
    addMarkers(sensorData4, coordinates4);
    addMarkers(sensorData5, coordinates5);
    addMarkers(sensorData6, coordinates6);

    function addMarkers(sensorData, coordinates) {
        for (var i = 0; i < sensorData.length; i++) {
            var marker = L.marker(coordinates).addTo(map);
            marker.bindPopup('<b>Name:</b> ' + sensorData[i].name + '<br>' +
                             '<b>Temperature:</b> ' + sensorData[i].temperature + '<br>' +
                             '<b>Humidity:</b> ' + sensorData[i].humidity + '<br>' +
                             '<b>Time:</b> ' + sensorData[i].time + '<br>' +
                             '<b>Voltage:</b> ' + sensorData[i].voltage + '<br>' +
                             '<b>Water Level:</b> ' + sensorData[i].water_level + '<br>');
        }
    }
</script>
<script>
    var lampungCoordinates = [
        [-5.714197, 105.573325],
        [-5.714175, 105.573990], 
        [-5.714645, 105.572703],
        [-5.715499, 105.573475], 
        [-5.713898, 105.571909], 
        [-5.713331, 105.570965] 
  ];

  
  var lampungPolygon = L.polygon(lampungCoordinates, {color: 'red'}).addTo(map);
</script>
</body>
</html>
