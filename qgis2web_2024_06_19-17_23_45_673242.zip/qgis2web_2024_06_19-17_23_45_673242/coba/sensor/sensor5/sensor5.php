<!DOCTYPE html>
<html>
<head>
    <title>Map with Sensor Data</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <h2>Data Sensor 5</h2>
    <div id="sensorTable"></div>
</div>

<?php
// Memasukkan file koneksi
require_once 'koneksi.php';

// Mengambil data dari tabel sensor_data_1 dengan prepared statements
$sql = "SELECT name, temperature, humidity, time, voltage, water_level FROM sensor_data_5";
$stmt = $conn->prepare($sql);

// Memeriksa apakah query berhasil dieksekusi
if ($stmt->execute()) {
    // Mengikat hasil query dengan variabel
    $stmt->bind_result($name, $temperature, $humidity, $time, $voltage, $water_level);

    // Memulai tabel
    echo "<table class='table'><thead><tr><th>Name</th><th>Temperature</th><th>Humidity</th><th>Time</th><th>Voltage</th><th>Water Level</th></tr></thead><tbody>";

    // Mengambil hasil query satu per satu dan menampilkannya dalam tabel HTML
    while ($stmt->fetch()) {
        echo "<tr><td>" . htmlspecialchars($name) . "</td><td>" . htmlspecialchars($temperature) . "</td><td>" . htmlspecialchars($humidity) . "</td><td>" . htmlspecialchars($time) . "</td><td>" . htmlspecialchars($voltage) . "</td><td>" . htmlspecialchars($water_level) . "</td></tr>";
    }

    // Menutup tabel
    echo "</tbody></table>";
} else {
    echo "Error executing query";
}

// Menutup statement
$stmt->close();

// Menutup koneksi
$conn->close();
?>

</body>
</html>
