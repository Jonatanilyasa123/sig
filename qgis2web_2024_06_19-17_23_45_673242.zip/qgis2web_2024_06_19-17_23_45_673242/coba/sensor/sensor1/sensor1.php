<!DOCTYPE html>
<html>
<head>
    <title>Map with Sensor Data</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
</head>
<body>
   

<div class="container mt-4">
    <h2>Data Sensor 1</h2>
    <p><a href="https://www.google.com/maps?q=-5.714197, 105.573325" target="_blank">Lihat Lokasi : -5.714197, 105.573325</a></p>
    <div id="sensorTable"></div>
</div>

<?php

require_once 'koneksi.php';


$sql = "SELECT name, temperature, humidity, time, voltage, water_level FROM sensor_data_1";
$stmt = $conn->prepare($sql);


if ($stmt->execute()) {
    
    $stmt->bind_result($name, $temperature, $humidity, $time, $voltage, $water_level);

    
    echo "<table class='table'><thead><tr><th>Name</th><th>Temperature</th><th>Humidity</th><th>Time</th><th>Voltage</th><th>Water Level</th></tr></thead><tbody>";

    
    while ($stmt->fetch()) {
        echo "<tr><td>" . htmlspecialchars($name) . "</td><td>" . htmlspecialchars($temperature) . "</td><td>" . htmlspecialchars($humidity) . "</td><td>" . htmlspecialchars($time) . "</td><td>" . htmlspecialchars($voltage) . "</td><td>" . htmlspecialchars($water_level) . "</td></tr>";
    }

    
    echo "</tbody></table>";
} else {
    echo "Error executing query";
}


$stmt->close();


$conn->close();
?>




</body>
</html>
