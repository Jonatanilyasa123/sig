<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Water Level Chart</title>
    <!-- Memasukkan Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <canvas id="waterLevelChart" width="800" height="400"></canvas>
    
    <script>
        // Mengatur data water level dari PHP ke variabel JavaScript
        var water_level_data = <?php echo json_encode($water_level_data); ?>;

        // Membuat grafik water level menggunakan Chart.js
        var ctx = document.getElementById('waterLevelChart').getContext('2d');
        var waterLevelChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: water_level_data.time,
                datasets: [{
                    label: 'Water Level',
                    data: water_level_data.water_level,
                    borderColor: 'blue',
                    fill: false
                }]
            },
            options: {
                responsive: false, // Mengatur responsivitas menjadi false agar kanvas tidak menyesuaikan ukuran browser
                maintainAspectRatio: false, // Mengatur agar aspek rasio kanvas tidak dipertahankan
                title: {
                    display: true,
                    text: 'Water Level Data'
                },
                scales: {
                    xAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'Time'
                        },
                        ticks: {
                            autoSkip: true, // Mengatur agar label sumbu x otomatis di-skip jika terlalu padat
                            maxRotation: 45, // Mengatur maksimum rotasi label sumbu x
                            minRotation: 45 // Mengatur minimum rotasi label sumbu x
                        }
                    }],
                    yAxes: [{
                        display: true,
                        scaleLabel: {
                            display: true,
                            labelString: 'Water Level'
                        }
                    }]
                }
            }
        });
    </script>
</body>
</html>
