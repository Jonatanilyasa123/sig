<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_sensorr";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT water_level, time FROM sensor_data_1";
$result = $conn->query($sql);


$data = array();

if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
       
        $data[] = array(
            'water_level' => $row["water_level"],
            'time' => $row["time"]
        );
    }
} else {
    echo "0 results";
}


$conn->close();


$response = array(
    'data' => $data
);


echo json_encode($response);
?>
