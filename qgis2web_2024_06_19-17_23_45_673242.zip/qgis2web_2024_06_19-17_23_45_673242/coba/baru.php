<?php

$servername1 = "localhost";
$username1 = "root";
$password1 = "";
$dbname1 = "db_sensorr";

$servername2 = "localhost";
$username2 = "root";
$password2 = "";
$dbname2 = "db_sensor2";


$conn1 = new mysqli($servername1, $username1, $password1, $dbname1);
$conn2 = new mysqli($servername2, $username2, $password2, $dbname2);


if ($conn1->connect_error || $conn2->connect_error) {
    die("Koneksi gagal: " . $conn1->connect_error . " atau " . $conn2->connect_error);
}


function clean_input($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}


$sql1 = "SELECT * FROM sensor_data_1";
$result1 = $conn1->query($sql1);

$sql2 = "SELECT * FROM sensor_data_2";
$result2 = $conn2->query($sql2);


$sensorData1 = array();
if ($result1->num_rows > 0) {
    while($row = $result1->fetch_assoc()) {
        $sensorData1[] = array(
            'coordinates' => array(floatval($row['latitude']), floatval($row['longitude'])),
            'name' => clean_input($row['name']),
            'temperature' => clean_input($row['temperature']),
            'humidity' => clean_input($row['humidity']),
            'time' => clean_input($row['time']),
            'voltage' => clean_input($row['voltage']),
            'water_level' => clean_input($row['water_level'])
        );
    }
}

$sensorData2 = array();
if ($result2->num_rows > 0) {
    while($row = $result2->fetch_assoc()) {
        $sensorData2[] = array(
            'coordinates' => array(floatval($row['latitude']), floatval($row['longitude'])),
            'name' => clean_input($row['name']),
            'temperature' => clean_input($row['temperature']),
            'humidity' => clean_input($row['humidity']),
            'time' => clean_input($row['time']),
            'voltage' => clean_input($row['voltage']),
            'water_level' => clean_input($row['water_level'])
        );
    }
}

$conn1->close();
$conn2->close();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Map with Sensor Data</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
</head>
<body>

<div id="map" style="height: 500px;"></div>

<script>
    var map = L.map('map').setView([0, 0], 2);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
    }).addTo(map);

   
    var sensorData1 = <?php echo json_encode($sensorData1); ?>;
    var sensorData2 = <?php echo json_encode($sensorData2); ?>;

    
    var sensorMarkers1 = [];
    for (var i = 0; i < sensorData1.length; i++) {
        var data = sensorData1[i];
        var marker = L.marker(data.coordinates).addTo(map);
        marker.bindPopup('<b>Name:</b> ' + data.name + '<br>' +
                         '<b>Temperature:</b> ' + data.temperature + '<br>' +
                         '<b>Humidity:</b> ' + data.humidity + '<br>' +
                         '<b>Time:</b> ' + data.time + '<br>' +
                         '<b>Voltage:</b> ' + data.voltage + '<br>' +
                         '<b>Water Level:</b> ' + data.water_level + '<br>');
        sensorMarkers1.push(marker);
    }

    var sensorMarkers2 = [];
    for (var i = 0; i < sensorData2.length; i++) {
        var data = sensorData2[i];
        var marker = L.marker(data.coordinates).addTo(map);
        marker.bindPopup('<b>Name:</b> ' + data.name + '<br>' +
                         '<b>Temperature:</b> ' + data.temperature + '<br>' +
                         '<b>Humidity:</b> ' + data.humidity + '<br>' +
                         '<b>Time:</b> ' + data.time + '<br>' +
                         '<b>Voltage:</b> ' + data.voltage + '<br>' +
                         '<b>Water Level:</b> ' + data.water_level + '<br>');
        sensorMarkers2.push(marker);
    }
    
  
    var group1 = new L.featureGroup(sensorMarkers1);
    var group2 = new L.featureGroup(sensorMarkers2);
    var group = L.featureGroup([group1, group2]);
    map.fitBounds(group.getBounds());
</script>

</body>
</html>
