<?php

$servername1 = "localhost";
$username1 = "root";
$password1 = "";
$dbname1 = "db_sensorr";

$servername2 = "localhost";
$username2 = "root";
$password2 = "";
$dbname2 = "db_sensor2";

$servername3 = "localhost";
$username3 = "root";
$password3 = "";
$dbname3 = "db_sensor3";

$servername4 = "localhost";
$username4 = "root";
$password4 = "";
$dbname4 = "db_sensor4";

$servername5 = "localhost";
$username5 = "root";
$password5 = "";
$dbname5 = "db_sensor5";

$servername6 = "localhost";
$username6 = "root";
$password6 = "";
$dbname6 = "db_sensor6";


$conn1 = new mysqli($servername1, $username1, $password1, $dbname1);
$conn2 = new mysqli($servername2, $username2, $password2, $dbname2);
$conn3 = new mysqli($servername3, $username3, $password3, $dbname3);
$conn4 = new mysqli($servername4, $username4, $password4, $dbname4);
$conn5 = new mysqli($servername5, $username5, $password5, $dbname5);
$conn6 = new mysqli($servername6, $username6, $password6, $dbname6);


if ($conn1->connect_error || $conn2->connect_error || $conn3->connect_error ||
    $conn4->connect_error || $conn5->connect_error || $conn6->connect_error) {
    die("Koneksi gagal: " . $conn1->connect_error . " atau " . $conn2->connect_error . " atau " .
        $conn3->connect_error . " atau " . $conn4->connect_error . " atau " .
        $conn5->connect_error . " atau " . $conn6->connect_error);
}


$sql1 = "SELECT * FROM sensor_data_1";
$result1 = $conn1->query($sql1);

$sql2 = "SELECT * FROM sensor_data_2";
$result2 = $conn2->query($sql2);

$sql3 = "SELECT * FROM sensor_data_3";
$result3 = $conn3->query($sql3);

$sql4 = "SELECT * FROM sensor_data_4";
$result4 = $conn4->query($sql4);

$sql5 = "SELECT * FROM sensor_data_5";
$result5 = $conn5->query($sql5);

$sql6 = "SELECT * FROM sensor_data_6";
$result6 = $conn6->query($sql6);


$sensorData1 = array();
if ($result1->num_rows > 0) {
    while($row = $result1->fetch_assoc()) {
        $sensorData1[] = array(
            'coordinates' => [-5.714197, 105.573325], 
            'name' => ['Sensor 1'],
            'temperature' => $row['temperature'],
            'humidity' => $row['humidity'],
            'time' => $row['time'],
            'voltage' => $row['voltage'],
            'water_level' => $row['water_level']
        );
    }
}

$sensorData2 = array();
if ($result2->num_rows > 0) {
    while($row = $result2->fetch_assoc()) {
        $sensorData2[] = array(
            'coordinates' => [-5.714175, 105.573990], 
            'name' => ['Sensor 2'],
            'temperature' => $row['temperature'],
            'humidity' => $row['humidity'],
            'time' => $row['time'],
            'voltage' => $row['voltage'],
            'water_level' => $row['water_level']
        );
    }
}

$sensorData3 = array();
if ($result3->num_rows > 0) {
    while($row = $result3->fetch_assoc()) {
        $sensorData3[] = array(
            'coordinates' => [-5.714645, 105.572703], 
            'name' => ['Sensor 3'],
            'temperature' => $row['temperature'],
            'humidity' => $row['humidity'],
            'time' => $row['time'],
            'voltage' => $row['voltage'],
            'water_level' => $row['water_level']
        );
    }
}

$sensorData4 = array();
if ($result4->num_rows > 0) {
    while($row = $result4->fetch_assoc()) {
        $sensorData4[] = array(
            'coordinates' => [-5.715499, 105.573475],
            'name' => ['Sensor 4'],
            'temperature' => $row['temperature'],
            'humidity' => $row['humidity'],
            'time' => $row['time'],
            'voltage' => $row['voltage'],
            'water_level' => $row['water_level']
        );
    }
}

$sensorData5 = array();
if ($result5->num_rows > 0) {
    while($row = $result5->fetch_assoc()) {
        $sensorData5[] = array(
            'coordinates' => [-5.713898, 105.571909], 
            'name' => ['Sensor 5'],
            'temperature' => $row['temperature'],
            'humidity' => $row['humidity'],
            'time' => $row['time'],
            'voltage' => $row['voltage'],
            'water_level' => $row['water_level']
        );
    }
}

$sensorData6 = array();
if ($result6->num_rows > 0) {
    while($row = $result6->fetch_assoc()) {
        $sensorData6[] = array(
            'coordinates' => [-5.713331, 105.570965], 
            'name' => ['Sensor 6'],
            'temperature' => $row['temperature'],
            'humidity' => $row['humidity'],
            'time' => $row['time'],
            'voltage' => $row['voltage'],
            'water_level' => $row['water_level']
        );
    }
}

$conn1->close();
$conn2->close();
$conn3->close();
$conn4->close();
$conn5->close();
$conn6->close();
?>
